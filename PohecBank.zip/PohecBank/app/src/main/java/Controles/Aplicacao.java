package Controles;

/**
 * Created by neto on 19/03/18.
 */

public class Aplicacao {

    public static int Cle_id ;
    public  static String CPF ;

}
