package Controles;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by neto on 19/03/18.
 */

public class Controle_Transacoes {
    private SQLiteDatabase db;
    private Pohec_DataBase dbPohec;
    public Controle_Transacoes(Context context)
    {
        dbPohec = new Pohec_DataBase(context);
    }


    public boolean guardarExtrato (String tipo_acao,double valor, String codigo_barra, boolean eh_pagamento)
    {
        int cle_id = Aplicacao.Cle_id;
        db = dbPohec.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("cle_id" , cle_id);
        values.put("tipo_acao" , tipo_acao);
        values.put("valor",valor);
        if(eh_pagamento)
        {
            values.put("codigo_barra",codigo_barra);
            values.put("eh_pagamento",eh_pagamento);
        }
        else
        {
            values.put("eh_pagamento",false);
        }
        return db.insert("transacoes",null,values)  != -1;
    }

    public List carregarExtrato()
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT tipo_acao,ifnull(valor,0) FROM transacoes where cle_id = '%s' order by id_transacoes DESC", Aplicacao.Cle_id);
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();
        List lista = new ArrayList<>();
        for (int i =0 ;  i <cursor.getCount() ; i ++)
        {
            String transacao  = "";
            if(cursor.getString(0) == null)
                transacao = "Pagamento ";
            else if (cursor.getString(0).equals("D") )
                transacao = "Deposito ";
            else if (cursor.getString(0).equals("T") )
                transacao = "Transferencia ";
            else if (cursor.getString(0).equals("P") )
                transacao = "Poupanca ";
            transacao += cursor.getDouble(1);
            lista.add(transacao);
            cursor.moveToNext();
        }
        return lista;
    }

    public List carregarExtratoDeposito()
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT ifnull(valor,0) FROM transacoes where cle_id = '%s' and tipo_acao = 'D' order by id_transacoes DESC", Aplicacao.Cle_id);
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();
        List lista = new ArrayList<>();
        for (int i =0 ;  i <cursor.getCount() ; i ++)
        {
            String transacao  = "Deposito ";
            transacao +=(cursor.getDouble(0));
            lista.add(transacao);
            cursor.moveToNext();
        }
        return lista;
    }

    public List carregarExtratoPagamentos()
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT codigo_barra, ifnull(valor,0) FROM transacoes where cle_id = '%s' and eh_pagamento = 1 order by id_transacoes DESC", Aplicacao.Cle_id);
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();
        List lista = new ArrayList<>();
        for (int i =0 ;  i <cursor.getCount() ; i ++)
        {
            lista.add("Valor : " + cursor.getDouble(1) + "\n Codigo de barras \n" + cursor.getString(0));
            cursor.moveToNext();
        }
        return lista;
    }

    public List carregarExtratoPoupanca()
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT tipo_acao,ifnull(valor,0) FROM transacoes where cle_id = '%s'  and tipo_acao = 'P'  order by id_transacoes DESC", Aplicacao.Cle_id);
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();
        List lista = new ArrayList<>();
        for (int i =0 ;  i <cursor.getCount() ; i ++)
        {
            String transacao  = "Poupanca ";
            transacao += cursor.getDouble(1);
            lista.add(transacao);
            cursor.moveToNext();
        }
        return lista;
    }


    public List carregarExtratoTransferencia()
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT tipo_acao,ifnull(valor,0) FROM transacoes where cle_id = '%s'  and tipo_acao = 'T'  order by id_transacoes DESC", Aplicacao.Cle_id);
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();
        List lista = new ArrayList<>();
        for (int i =0 ;  i <cursor.getCount() ; i ++)
        {
            String transacao  = "Transferencia ";
            transacao += cursor.getDouble(1);
            lista.add(transacao);
            cursor.moveToNext();
        }
        return lista;
    }


}
