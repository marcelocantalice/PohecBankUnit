package Controles;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by neto on 19/03/18.
 */

public class Controle_Cliente {
    private static SQLiteDatabase db;
    private static Pohec_DataBase dbPohec;
    public Controle_Cliente(Context context)
    {
        dbPohec = new Pohec_DataBase(context);
    }

    public Boolean Cadastrar(String cle_CPF, String cle_senha)
    {
        db = dbPohec.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("cle_CPF",cle_CPF.replace(".","").replace("-",""));
        values.put("cle_senha",cle_senha.replace(".",""));
        return  db.insert("cliente",null,values) != -1 ;
    }

    public Boolean Autenticar(String cpf, String senha)
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT * FROM cliente where cle_CPF = '%s' and cle_senha = '%s'",cpf.replace(".","").replace("-",""), senha.replace(".",""));
        Cursor cursor = db.rawQuery(sql,null);
        boolean autenticado = cursor.getCount() > 0;
        cursor.close();
        return autenticado;

    }

    public int obterID(String cpf)
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT cle_id FROM cliente where cle_CPF = '%s' ",cpf.replace(".","").replace("-",""));
        Cursor cursor = db.rawQuery(sql,null);
        if(cursor.getCount() == 0){
            cursor.close(); return -1;}
        cursor.moveToFirst();
        int id = cursor.getInt(0);
        cursor.close();
        return id;

    }

}
