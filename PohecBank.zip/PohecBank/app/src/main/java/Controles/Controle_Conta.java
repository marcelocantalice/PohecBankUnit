package Controles;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by neto on 19/03/18.
 */

public class Controle_Conta {
    private SQLiteDatabase db;
    private Pohec_DataBase dbPohec;
    Controle_Transacoes transacao;
    public Controle_Conta(Context context)
    {
        dbPohec = new Pohec_DataBase(context);
        cadastrarConta();
        transacao = new Controle_Transacoes(context);
    }
    public double obterValorContaCorrente(int cle_id)
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT  ifnull(valor,0) FROM conta where cle_id = %s  and tipo_conta = 'C'", cle_id);
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();
        double saldo = cursor.getDouble(0);
        cursor.close();
        return saldo;

    }


    public double obterValorPoupanca(int cle_id)
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT  ifnull(valor,0) FROM conta where cle_id = %s and tipo_conta = 'P' ",  cle_id);
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();
        double poupanca = cursor.getDouble(0);
        cursor.close();
        return poupanca;
    }


    public boolean aplicarDeposito(double valor,int cle_id, boolean guardarExtrato){
        db = dbPohec.getReadableDatabase();
        ContentValues values = new ContentValues();
        double v =valor + obterValorContaCorrente(cle_id);
        values.put("valor",v);
        int retorno = db.update("conta",values,"tipo_conta = 'C' and cle_id = " + cle_id,null)  ;

    if(retorno != -1 && guardarExtrato)
        transacao.guardarExtrato("D",valor,null,false);
        return retorno != -1;
    }

    public boolean aplicarPoupanca(double valor, int cle_id){
        if(valor > obterValorContaCorrente(Aplicacao.Cle_id)) return false;
        db = dbPohec.getReadableDatabase();
        ContentValues values = new ContentValues();
        double v =valor + obterValorPoupanca(cle_id);
        values.put("valor",v);
        boolean retorno = db.update("conta",values,"tipo_conta = 'P' and cle_id = " + cle_id,null)  != -1 ;
        if(retorno){
            transacao.guardarExtrato("P",valor,null,false);
            aplicarDeposito(-valor,cle_id,false);
        }
        return retorno;
    }


    public boolean aplicarTransferencia(double valor, int cle_id,String tipo_Conta) {
        if(valor > obterValorContaCorrente(Aplicacao.Cle_id)) return false;
        db = dbPohec.getReadableDatabase();
        ContentValues values = new ContentValues();
        String where = "";
        double v =valor;
        if(tipo_Conta.equals("C")) {
            where += "tipo_conta = 'C'";
            v+= + obterValorContaCorrente(cle_id);
        }
        else if(tipo_Conta.equals("P")){
            where += "tipo_conta = 'P'";
            v+= obterValorPoupanca(cle_id);
        }

        values.put("valor",v);
        boolean retorno = db.update("conta",values,where + " and cle_id = " + cle_id,null)  != -1 ;
        if(!retorno) return false;
        aplicarDeposito(-valor,Aplicacao.Cle_id, false);
        transacao.guardarExtrato("T",valor,null,false);
        return  true;
    }

    public boolean realizarPagamento(double valor, String codigoBarra){
        if(valor > obterValorContaCorrente(Aplicacao.Cle_id)) return false;
        db = dbPohec.getReadableDatabase();
        ContentValues values = new ContentValues();
        double v =obterValorContaCorrente(Aplicacao.Cle_id)  -valor;
        values.put("tipo_conta ", "C");
        values.put("valor",v);
        boolean retorno = db.update("conta",values,"tipo_conta = 'C' and cle_id = " + Aplicacao.Cle_id,null) != -1;
        if(retorno)transacao.guardarExtrato(null,valor,codigoBarra,true);
        return retorno;
    }

    private void cadastrarConta ()
    {
        if(contaCadastrada()) return;
        cadastrar_ContaCorrente();
        cadastrar_Poupanca();
    }

    void cadastrar_ContaCorrente()
    {
        db = dbPohec.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("tipo_conta","C");
        values.put("cle_id",Aplicacao.Cle_id);
        values.put("valor",0);
        db.insert("conta",null,values)  ;

    }
    void cadastrar_Poupanca(){
        db = dbPohec.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("tipo_conta","P");
        values.put("cle_id",Aplicacao.Cle_id);
        values.put("valor",0);
        db.insert("conta",null,values)  ;

    }

    private Boolean contaCadastrada()
    {
        db = dbPohec.getReadableDatabase();
        String sql = String.format("SELECT  * FROM conta where cle_id = %s ", Aplicacao.Cle_id);
        Cursor cursor = db.rawQuery(sql,null);
        boolean existe = cursor.getCount() > 0 ;
        cursor.close();
        return existe;

    }
}
