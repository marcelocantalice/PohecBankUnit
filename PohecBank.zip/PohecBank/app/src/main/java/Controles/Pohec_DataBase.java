package Controles;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by neto on 19/03/18.
 */

public class Pohec_DataBase extends SQLiteOpenHelper {
    private static final String DB_NOME = "pohecbank.db";
    private static final int DB_VERSION  = 1;
    public Pohec_DataBase(Context context) {
        super(context, DB_NOME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String CREATE_CLIENTE = "CREATE TABLE IF NOT EXISTS cliente(cle_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, cle_CPF VARCHAR(100) UNIQUE, cle_senha VARCHAR(20) NOT NULL)";
        db.execSQL(CREATE_CLIENTE);
        //(D)epositar (T)ransferencia , (P)oupanca
        // caso seja pagamento há uma flag separada
        final String CREATE_TRANSACOES = "CREATE TABLE IF NOT EXISTS transacoes(id_transacoes INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL, cle_id INTEGER , tipo_acao varchar(1) , valor double(11,2) NOT NULL, codigo_barra varchar(60), eh_pagamento boolean)";
        db.execSQL(CREATE_TRANSACOES);
        // (C)orrente ou (P)oupanca
        // Ao entrar no menuPrincipal e buscar os dados da conta é verificado se a conta corrente ou poupança existe, caso não é criado.
        final String CREATE_CONTA = "CREATE TABLE IF NOT EXISTS conta(conta_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, cle_id INTEGER, tipo_conta varchar(1) NOT NULL, valor double(11,2) NOT NULL)";
        db.execSQL(CREATE_CONTA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
