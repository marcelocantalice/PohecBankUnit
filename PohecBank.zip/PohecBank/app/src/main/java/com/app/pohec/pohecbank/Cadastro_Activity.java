package com.app.pohec.pohecbank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import Controles.Controle_Cliente;
import br.com.jansenfelipe.androidmask.MaskEditTextChangedListener;

public class Cadastro_Activity extends AppCompatActivity {
EditText txtCPF;
EditText txtSenha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        txtCPF = findViewById(R.id.Cadastro_txtCPF);
        txtSenha = findViewById(R.id.Cadastro_txtSenha);
        MaskEditTextChangedListener maskCPF = new MaskEditTextChangedListener("###.###.###-##", txtCPF);
        txtCPF.addTextChangedListener(maskCPF);
        this.setTitle("PohecBank - Cadastro");
    }

    public void CadastrarCliente (View view)
    {
        Controle_Cliente cliente = new Controle_Cliente(getBaseContext());
        String retorno  = cliente.Cadastrar(txtCPF.getText().toString(),txtSenha.getText().toString()) ? "Cadastro realizado com sucesso" : "Erro ao cadastrar usuario";
        Toast.makeText(getBaseContext(),retorno,Toast.LENGTH_SHORT).show();
    }
}
