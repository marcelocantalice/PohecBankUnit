package com.app.pohec.pohecbank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import Controles.Aplicacao;
import Controles.Controle_Conta;
import Controles.Controle_Transacoes;

public class Poupanca_Activity extends AppCompatActivity {
EditText txtValorPoupanca;
ListView listapoupanca;

    Controle_Transacoes transacao ;
    Controle_Conta controleConta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poupanca_);
        txtValorPoupanca = findViewById(R.id.txtValorPoupanca);
        listapoupanca = findViewById(R.id.listaPoupanca);
        controleConta = new Controle_Conta(getBaseContext());
        transacao = new Controle_Transacoes(getBaseContext());
        obterPoupanca();
        this.setTitle("PohecBank - Poupança");
    }

    void obterPoupanca(){

        ArrayAdapter<String> array = new ArrayAdapter<String>(getBaseContext(),android.R.layout.simple_list_item_1, transacao.carregarExtratoPoupanca());
        listapoupanca.setAdapter(array);

    }

    void exibirMsg(String msg){
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();}

    public void Poupanca(View view)
    {
        if(txtValorPoupanca.getText().toString().isEmpty())
        {
            Toast.makeText(getBaseContext(),"Valor está em branco",Toast.LENGTH_SHORT).show();
            return;
        }

        if(controleConta.aplicarPoupanca(Double.parseDouble(txtValorPoupanca.getText().toString()), Aplicacao.Cle_id))
        {exibirMsg("Valor depositado na poupança com sucesso!"); obterPoupanca();}
        else
        {
            exibirMsg("Erro ao depositar  o valor na poupança");
        }

    }
}
