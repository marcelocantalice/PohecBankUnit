package com.app.pohec.pohecbank;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import Controles.Aplicacao;
import Controles.Controle_Cliente;
import br.com.jansenfelipe.androidmask.MaskEditTextChangedListener;

public class MainActivity extends AppCompatActivity {
EditText txtCPF;
EditText txtSenha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtCPF = findViewById(R.id.MainActivity_txtCPF);
        txtSenha = findViewById(R.id.MainActivity_txtSenha);
        MaskEditTextChangedListener maskCPF = new MaskEditTextChangedListener("###.###.###-##", txtCPF);
        txtCPF.addTextChangedListener(maskCPF);

    }

    public void MainActivity_Cadastrar (View view)
    {

        Intent it = new Intent(this,Cadastro_Activity.class);
        startActivity(it);

    }


    public void MainActivity_Logar(View view )
    {

        Controle_Cliente controle = new Controle_Cliente(getBaseContext());
        if(controle.Autenticar(txtCPF.getText().toString(),txtSenha.getText().toString()))
        {
            Aplicacao.Cle_id = controle.obterID(txtCPF.getText().toString());
            Aplicacao.CPF = txtCPF.getText().toString().replace(".","").replace("-","");
            Intent it = new Intent(this, MenuPrincipal_Activity.class);
            startActivity(it);
        }
        else
            Toast.makeText(getBaseContext(), "Usuário não autenticado", Toast.LENGTH_SHORT).show();


    }
}
