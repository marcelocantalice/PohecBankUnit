package com.app.pohec.pohecbank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import Controles.Aplicacao;
import Controles.Controle_Conta;
import Controles.Controle_Transacoes;

public class Deposito_Activity extends AppCompatActivity {
    EditText txtValor;
    ListView listaDepositos;
    Controle_Transacoes controleTransacao  ;
    Controle_Conta controleConta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposito);
        txtValor = findViewById(R.id.txtValorDeposito);
        listaDepositos = findViewById(R.id.listaDeposito);
        controleTransacao = new Controle_Transacoes(getBaseContext());
        controleConta = new Controle_Conta(getBaseContext());
        obterDepositos();
        this.setTitle("PohecBank - Depósitos");
    }
    void obterDepositos()
    {

        ArrayAdapter<String> array = new ArrayAdapter<String>(getBaseContext(),android.R.layout.simple_list_item_1, controleTransacao.carregarExtratoDeposito());
        listaDepositos.setAdapter(array);

    }

    void exibirMsg(String msg){
    Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();}
    public void Depositar(View view)
    {
        if(txtValor.getText().toString().isEmpty())
        {
            Toast.makeText(getBaseContext(),"Valor está em branco",Toast.LENGTH_SHORT).show();
            return;
        }

        if(controleConta.aplicarDeposito(Double.parseDouble(txtValor.getText().toString()), Aplicacao.Cle_id,true))
        {exibirMsg("Valor depositado na conta corrente com sucesso!"); obterDepositos();}
        else
            {
            exibirMsg("Erro ao depositar o valor na conta corrente");
            }

    }
}
