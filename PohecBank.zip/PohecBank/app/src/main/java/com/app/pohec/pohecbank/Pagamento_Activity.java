package com.app.pohec.pohecbank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import Controles.Aplicacao;
import Controles.Controle_Conta;
import Controles.Controle_Transacoes;
import br.com.jansenfelipe.androidmask.MaskEditTextChangedListener;

public class Pagamento_Activity extends AppCompatActivity {
    EditText txtCodigoBarras;
    EditText txtValor;
    Button btPagar;
    ListView listaPagamento;
    Controle_Transacoes transacao ;
    Controle_Conta controleConta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamento_);
        txtCodigoBarras = findViewById(R.id.txtCodigoBarras);
        txtValor = findViewById(R.id.txtValorPagamento);
        listaPagamento = findViewById(R.id.lIstaPagamento);
        controleConta = new Controle_Conta(getBaseContext());
        transacao = new Controle_Transacoes(getBaseContext());
        MaskEditTextChangedListener maskCPF = new MaskEditTextChangedListener("#####.#####/#####.#####/#####.#####/#/##############", txtCodigoBarras);
        txtCodigoBarras.addTextChangedListener(maskCPF);
        obterPagamento();
        this.setTitle("PohecBank - Pagamentos");
    }


    void obterPagamento(){
        ArrayAdapter<String> array = new ArrayAdapter<String>(getBaseContext(),android.R.layout.simple_list_item_1, transacao.carregarExtratoPagamentos());
        listaPagamento.setAdapter(array);
    }

    void exibirMsg(String msg){
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();}

    public void Pagamento(View view)
    {
        if(txtValor.getText().toString().isEmpty())
        {
            Toast.makeText(getBaseContext(),"Valor está em branco",Toast.LENGTH_SHORT).show();
            return;
        }

        if(controleConta.realizarPagamento(Double.parseDouble(txtValor.getText().toString()),txtCodigoBarras.getText().toString()))
        {exibirMsg("Pagamento realizado com sucesso!"); obterPagamento();}
        else
        {
            exibirMsg("Erro ao realizar pagamento");
        }

    }

}
