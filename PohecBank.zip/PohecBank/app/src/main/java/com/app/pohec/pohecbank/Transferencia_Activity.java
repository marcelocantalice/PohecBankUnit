package com.app.pohec.pohecbank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import Controles.Aplicacao;
import Controles.Controle_Cliente;
import Controles.Controle_Conta;
import Controles.Controle_Transacoes;
import br.com.jansenfelipe.androidmask.MaskEditTextChangedListener;

public class Transferencia_Activity extends AppCompatActivity {
    EditText txtValor;
    EditText txtcpf;
    RadioButton rb_Corrente;
    ListView listaTransferencia;
    Controle_Transacoes transacao ;
    Controle_Conta controleConta;
    Controle_Cliente controleCliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transferencia);
        txtValor = findViewById(R.id.txtValorTransferencia);
        txtcpf = findViewById(R.id.txtCPFTransferencia);
        rb_Corrente = findViewById(R.id.rbTransferenciaCorrente);
        rb_Corrente.setChecked(true);
        controleConta = new Controle_Conta(getBaseContext());
        transacao = new Controle_Transacoes(getBaseContext());
        controleCliente = new Controle_Cliente(getBaseContext());
        listaTransferencia = findViewById(R.id.listaTransferencia);
        MaskEditTextChangedListener maskCPF = new MaskEditTextChangedListener("###.###.###-##", txtcpf);
        txtcpf.addTextChangedListener(maskCPF);
        obterTransferencia();
        this.setTitle("PohecBank - Transferências");
    }

    void obterTransferencia(){
        ArrayAdapter<String> array = new ArrayAdapter<String>(getBaseContext(),android.R.layout.simple_list_item_1, transacao.carregarExtratoTransferencia());
        listaTransferencia.setAdapter(array);
    }

    void exibirMsg(String msg){
        Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();}

    public void Transferencia(View view)
    {
        if(txtValor.getText().toString().isEmpty())
        {
            exibirMsg("Valor está em branco");
            return;
        }
        int id_Destinatario = controleCliente.obterID(txtcpf.getText().toString().replace(".","").replace("-",""));
        if(id_Destinatario == -1) {exibirMsg("Usuário não existe"); return;}
        if(controleConta.aplicarTransferencia(Double.parseDouble(txtValor.getText().toString()), id_Destinatario,rb_Corrente.isChecked() ? "C" : "P"))
        {exibirMsg("Valor transferido com sucesso!"); obterTransferencia();}
        else exibirMsg("Erro ao transferir");


    }
}
