package com.app.pohec.pohecbank;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import Controles.Aplicacao;
import Controles.Controle_Conta;
import Controles.Controle_Transacoes;

public class MenuPrincipal_Activity extends AppCompatActivity {
    TextView txtSaldo;
    TextView txtPoupanca;
    ListView listaExtrato;
    TextView txtCPF;
    Controle_Conta conta;
    Controle_Transacoes transacoes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        txtSaldo = findViewById(R.id.MenuPrincipal_txtSaldo);
        txtPoupanca= findViewById(R.id.MenuPrincipal_txtPoupanca);
        listaExtrato = findViewById(R.id.MenuPrincipal_listaExtrato);
        txtCPF = findViewById(R.id.MenuPrincipal_txtCPF);
        StringBuilder str = new StringBuilder();
        str.append(Aplicacao.CPF);
        str.insert(3,'.');str.insert(7,'.');str.insert(11,'-');
        txtCPF.setText( "CPF : "+ str.toString());
        conta= new Controle_Conta(getBaseContext());
        transacoes = new Controle_Transacoes(getBaseContext());
        carregarDados();

    }

    @Override
    protected void onResume() {
        carregarDados();
        super.onResume();
    }

    private void carregarDados()
    {
        txtPoupanca.setText(conta.obterValorPoupanca(Aplicacao.Cle_id) + "");
        txtSaldo.setText(conta.obterValorContaCorrente(Aplicacao.Cle_id) + "");
        ArrayAdapter<String> array = new ArrayAdapter<String>(getBaseContext(),android.R.layout.simple_list_item_1, transacoes.carregarExtrato());
        listaExtrato.setAdapter(array);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu_principal_, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (item.getTitle().toString().equals("Pagamento")) {
            //pagar
            Intent it = new Intent(getBaseContext(),Pagamento_Activity.class);
            startActivity(it);
        }
       else if (item.getTitle().toString().equals("Depositar")) {
            //Deposito
            Intent it = new Intent(getBaseContext(),Deposito_Activity.class);
            startActivity(it);
        }
        else if (item.getTitle().toString().equals("Transferência")) {
            //Transferencia
            Intent it = new Intent(getBaseContext(),Transferencia_Activity.class);
            startActivity(it);
        }
        else if (item.getTitle().toString().equals("Poupança")) {
            Intent it = new Intent(getBaseContext(),Poupanca_Activity.class);
            startActivity(it);
        }


        return super.onOptionsItemSelected(item);
    }
}
